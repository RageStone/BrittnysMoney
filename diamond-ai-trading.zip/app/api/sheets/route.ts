import { type NextRequest, NextResponse } from "next/server"

const SHEET_ID = "1oxZJKLN2DVV1c1PLhUVQgZJ4QA6iGTKC9hcEBCD8fpw"
const API_KEY = process.env.GOOGLE_SHEETS_API_KEY || "AIzaSyBvqp7_example_key" // You'll need to add this

// Helper function to convert column number to letter
function numberToColumn(num: number): string {
  let result = ""
  while (num > 0) {
    num--
    result = String.fromCharCode(65 + (num % 26)) + result
    num = Math.floor(num / 26)
  }
  return result
}

async function getFirstSheetName(): Promise<string> {
  const res = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${SHEET_ID}?fields=sheets.properties.title&key=${API_KEY}`,
  )
  const meta = await res.json()
  return meta?.sheets?.[0]?.properties?.title ?? "Sheet1"
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const action = searchParams.get("action")

    if (action === "fetch") {
      const sheetName = await getFirstSheetName() // NEW 🔽
      const response = await fetch(
        `https://sheets.googleapis.com/v4/spreadsheets/${SHEET_ID}/values/${encodeURIComponent(
          sheetName + "!A:W",
        )}?key=${API_KEY}`,
      )

      if (!response.ok) {
        const msg = await response.text().catch(() => "[no body]")
        console.error("Sheets API error:", response.status, msg) // NEW 🔽
        throw new Error("Failed to fetch from Google Sheets")
      }

      const data = await response.json()
      const rows = data.values || []

      if (rows.length <= 1) {
        return NextResponse.json({ signals: [] })
      }

      // Skip header row and convert to signal objects
      const signals = rows.slice(1).map((row: any[]) => ({
        id: row[0] || "",
        pair: row[1] || "",
        direction: row[2] || "BUY",
        entryPrice: Number.parseFloat(row[3]) || 0,
        stopLoss: Number.parseFloat(row[4]) || 0,
        takeProfit: Number.parseFloat(row[5]) || 0,
        timeframe: row[6] || "",
        confidence: Number.parseInt(row[7]) || 0,
        timestamp: new Date(row[8] || Date.now()),
        currentPrice: Number.parseFloat(row[9]) || 0,
        reasoning: row[10] || "",
        status: row[11] || "ACTIVE",
        exitPrice: row[12] ? Number.parseFloat(row[12]) : undefined,
        pnl: row[13] ? Number.parseFloat(row[13]) : undefined,
        pnlPercent: row[14] ? Number.parseFloat(row[14]) : undefined,
        checkedAt: row[15] ? new Date(row[15]) : undefined,
        indicators: {
          rsi: Number.parseFloat(row[16]) || 50,
          stoch: Number.parseFloat(row[17]) || 50,
          williams: Number.parseFloat(row[18]) || -50,
          cci: Number.parseFloat(row[19]) || 0,
          atr: Number.parseFloat(row[20]) || 0.001,
          sma: Number.parseFloat(row[21]) || 1,
          ema: Number.parseFloat(row[22]) || 1,
          momentum: Number.parseFloat(row[23]) || 0,
        },
      }))

      return NextResponse.json({ signals })
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 })
  } catch (error) {
    console.error("Sheets API error:", error)
    return NextResponse.json({ error: "Failed to process request" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { action, signal, signals } = body

    if (action === "add") {
      // Add a single signal to the sheet
      const values = [
        [
          signal.id,
          signal.pair,
          signal.direction,
          signal.entryPrice,
          signal.stopLoss,
          signal.takeProfit,
          signal.timeframe,
          signal.confidence,
          signal.timestamp.toISOString(),
          signal.currentPrice,
          signal.reasoning,
          signal.status,
          signal.exitPrice || "",
          signal.pnl || "",
          signal.pnlPercent || "",
          signal.checkedAt ? signal.checkedAt.toISOString() : "",
          signal.indicators.rsi,
          signal.indicators.stoch,
          signal.indicators.williams,
          signal.indicators.cci,
          signal.indicators.atr,
          signal.indicators.sma,
          signal.indicators.ema,
          signal.indicators.momentum,
        ],
      ]

      const sheetName = await getFirstSheetName()
      const appendUrl = `https://sheets.googleapis.com/v4/spreadsheets/${SHEET_ID}/values/${encodeURIComponent(
        sheetName + "!A:W:append",
      )}?valueInputOption=RAW&key=${API_KEY}`

      const response = await fetch(appendUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          values,
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to add to Google Sheets")
      }

      return NextResponse.json({ success: true })
    }

    if (action === "update") {
      // Update an existing signal
      // First, find the row number for this signal ID
      const sheetName = await getFirstSheetName()
      const fetchResponse = await fetch(
        `https://sheets.googleapis.com/v4/spreadsheets/${SHEET_ID}/values/${encodeURIComponent(
          sheetName + "!A:A",
        )}?key=${API_KEY}`,
      )

      const fetchData = await fetchResponse.json()
      const ids = fetchData.values || []

      let rowNumber = -1
      for (let i = 1; i < ids.length; i++) {
        // Skip header
        if (ids[i][0] === signal.id) {
          rowNumber = i + 1 // Google Sheets is 1-indexed
          break
        }
      }

      if (rowNumber === -1) {
        return NextResponse.json({ error: "Signal not found" }, { status: 404 })
      }

      // Update the specific row
      const values = [
        [
          signal.id,
          signal.pair,
          signal.direction,
          signal.entryPrice,
          signal.stopLoss,
          signal.takeProfit,
          signal.timeframe,
          signal.confidence,
          signal.timestamp.toISOString(),
          signal.currentPrice,
          signal.reasoning,
          signal.status,
          signal.exitPrice || "",
          signal.pnl || "",
          signal.pnlPercent || "",
          signal.checkedAt ? signal.checkedAt.toISOString() : "",
          signal.indicators.rsi,
          signal.indicators.stoch,
          signal.indicators.williams,
          signal.indicators.cci,
          signal.indicators.atr,
          signal.indicators.sma,
          signal.indicators.ema,
          signal.indicators.momentum,
        ],
      ]

      const response = await fetch(
        `https://sheets.googleapis.com/v4/spreadsheets/${SHEET_ID}/values/${encodeURIComponent(
          sheetName + "!A" + rowNumber + ":W" + rowNumber,
        )}?valueInputOption=RAW&key=${API_KEY}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            values,
          }),
        },
      )

      if (!response.ok) {
        throw new Error("Failed to update Google Sheets")
      }

      return NextResponse.json({ success: true })
    }

    if (action === "init") {
      const sheetName = await getFirstSheetName()

      // Check if the first row already contains headers
      const headRes = await fetch(
        `https://sheets.googleapis.com/v4/spreadsheets/${SHEET_ID}/values/${encodeURIComponent(
          sheetName + "!A1",
        )}?key=${API_KEY}`,
      )
      const headJson = await headRes.json()
      if (headJson.values?.length) {
        // Headers already present – nothing to do
        return NextResponse.json({ success: true })
      }

      const headers = [
        "ID",
        "Pair",
        "Direction",
        "Entry Price",
        "Stop Loss",
        "Take Profit",
        "Timeframe",
        "Confidence",
        "Timestamp",
        "Current Price",
        "Reasoning",
        "Status",
        "Exit Price",
        "PnL",
        "PnL %",
        "Checked At",
        "RSI",
        "Stochastic",
        "Williams %R",
        "CCI",
        "ATR",
        "SMA",
        "EMA",
        "Momentum",
      ]

      const initRes = await fetch(
        `https://sheets.googleapis.com/v4/spreadsheets/${SHEET_ID}/values/${encodeURIComponent(
          sheetName + "!A1:W1",
        )}?valueInputOption=RAW&key=${API_KEY}`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ values: [headers] }),
        },
      )

      if (!initRes.ok) {
        const txt = await initRes.text().catch(() => "[no body]")
        console.error("Sheets init error:", initRes.status, txt)
        throw new Error("Failed to initialize Google Sheets")
      }

      return NextResponse.json({ success: true })
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 })
  } catch (error) {
    console.error("Sheets API error:", error)
    return NextResponse.json({ error: "Failed to process request" }, { status: 500 })
  }
}
